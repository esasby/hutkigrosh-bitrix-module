<?
$arModuleVersion = array(
    "VERSION" => "2.1.0",
    "VERSION_DATE" => "2018-09-25 1:08:00"
);
?>