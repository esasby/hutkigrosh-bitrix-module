<?
$arModuleVersion = array(
    "VERSION" => "2.0.0",
    "VERSION_DATE" => "2018-08-16 7:00:00"
);
?>