<?
$MESS["hutkigrosh_MODULE_NAME"] = "Модуль платежной системы ХуткiГрош";
$MESS["hutkigrosh_MODULE_DESC"] = "Платежный модуль для приема платежей c помощью системы ЕРИП";
$MESS["hutkigrosh_PARTNER_NAME"] = "ESAS";
$MESS["hutkigrosh_PARTNER_URI"] = "http://esas.by";
$MESS["hutkigrosh_PS_NAME"] = "ХуткiГрош (ЕРИП)";
$MESS["hutkigrosh_PS_DESC"] = "«Хуткi Грош»™ — платежный сервис по выставлению счетов в АИС \"Расчет\" (ЕРИП).
После выставления счета Вам будет доступна его оплата пластиковой карточкой и электронными деньгами, в любом из отделений банков, кассах, банкоматах, платежных терминалах, в системе электронных денег, через Интернет-банкинг, М-банкинг, интернет-эквайринг";
$MESS["hutkigrosh_PS_ACTION_NAME"] = "ХуткiГрош (ЕРИП)";
$MESS["hutkigrosh_ERROR_PS_INSTALL"] = "Не удалось создать платёжную систему";
$MESS["hutkigrosh_ERROR_SALE_MODULE_NOT_INSTALLED"] = "Для работы модуля необходим модуль интернет-магазина (sale)";
$MESS["hutkigrosh_ERROR_CURL_NOT_INSTALLED"] = "Для работы модуля необходима библиотека curl";
$MESS["hutkigrosh_ERROR_ORDERS_EXIST"] = "Невозможно удалить платежную систему \"ХуткiГрош\", т.к. существуют заказы с данной платёжной системой. ";
$MESS["hutkigrosh_ERROR_DELETE_EXCEPTION"] = "Невозможно удалить платежную систему \"ХуткiГрош\".";
$MESS["hutkigrosh_ERROR_PS_ACTION_REG"] = "Ошибка регистрации обработчиков ПС";
?>