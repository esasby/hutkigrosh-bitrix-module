<?
Class CArtpayPayment 
{
}
?>
